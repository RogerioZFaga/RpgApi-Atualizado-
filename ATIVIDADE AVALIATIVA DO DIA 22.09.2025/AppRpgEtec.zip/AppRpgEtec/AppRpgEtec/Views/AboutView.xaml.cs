namespace AppRpgEtec.Views;

public partial class AboutView : ContentPage
{
	public AboutView()
	{
		InitializeComponent();
	}
}