namespace AppRpgEtec.Views;

public partial class DescriptionView : ContentPage
{
	public DescriptionView()
	{
		InitializeComponent();
	}
}