namespace AppRpgEtec.Views.Usuarios;

public partial class ListagemView : ContentPage
{
	public ListagemView()
	{
		InitializeComponent();
	}
}